function [ fncs ] = rules()
    % DO NOT EDIT
    fncs = l2.getRules();
    for i=1:length(fncs)
        fncs{i} = str2func(fncs{i});
    end
end
%DDR1
function result = ddr1(trace, params, t)
    result = {};
    
    for assumption = l2.getall(trace,t,'assumption_x',{NaN,NaN})
        agent = assumption.arg{1,1};
        ass = assumption.arg{1,2};

        result = {result{:} {t+1, 'belief_x', {agent,ass}}};
    end
end

function result = ddr2(trace,params,t)
    result = {};
    
    for belief = l2.getall(trace,t,'belief_x',{NaN,NaN})
        for situation =  l2.getall(trace,t,'observing_a_situation',{NaN})
            situation = situation.arg{1};
            agent = belief.arg{1,1};
            
            if strcmp(belief.arg{1,2}.name , 'support_system')
                bool = belief.arg{1,2}.arg{1,1};
                if bool == true 
                    interpretation = predicate('interpretation_of_situation',{situation,'emergency'});
                    result = {result{:} {t+1, 'belief_x', {agent,interpretation}}};
                end
            end
        end
    end       
end

function result = ddr3(trace,params,t)
    result = {};
    for belief = l2.getall(trace,t,'belief_x',{NaN,NaN})
        if strcmp(belief.arg{1,2}.name, 'interpretation_of_situation') & strcmp(belief.arg{1,2}.arg{1,2},'emergency')
            agent = belief.arg{1,1};
            assistance = predicate('form_of_assistance','intervene');
            result = {result{:} {t+1, 'belief_x', {agent,assistance}}};
        end
    end
end

function result = ddr4(trace,params,t)
    result = {};    
    for desire = l2.getall(trace,t,'desire_x',{NaN,NaN})
        agent = desire.arg{1,1};
        
        desire = desire.arg{1,2}.arg{1,1};
        
        for belief = l2.getall(trace,t,'belief_x',{NaN,NaN}) 
            if strcmp(belief.arg{1,2}.name, 'form_of_assistance')
                if strcmp(desire, belief.arg{1,2}.arg{1,1})
                    
                    result = {result{:} {t+1, 'proposed_x', {agent,belief.arg{1,2}}}};
                    
                end
            end
        end
    end
end






